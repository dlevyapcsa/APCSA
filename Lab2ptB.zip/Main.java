class Main {
  public static void main(String[] args) {
    // first three digits
  int numo = (int)(Math.random() *7)+1;
  int numt = (int)(Math.random() *7);
  int numth = (int)(Math.random() *7);
  // next three digits
  int fumo = (int)(Math.random() *10);
  int fumt = (int)(Math.random() *10);
  int fumth = (int)(Math.random() *10);
  // last four digits
  int tumo = (int)(Math.random() *10);
  int tumt = (int)(Math.random() *10);
  int tumth = (int)(Math.random() *10);
  int tumf = (int)(Math.random() *10);

  // print random number
  System.out.print(numo);
  System.out.print(numt);
  System.out.print(numth);
  System.out.print("-");
  System.out.print(fumo);
  System.out.print(fumt);
  System.out.print(fumth);
  System.out.print("-");
  System.out.print(tumo);
  System.out.print(tumt);
  System.out.print(tumth);
  System.out.print(tumf);
  
  
  }
}