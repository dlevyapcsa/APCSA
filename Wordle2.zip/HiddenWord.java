public class HiddenWord {

}